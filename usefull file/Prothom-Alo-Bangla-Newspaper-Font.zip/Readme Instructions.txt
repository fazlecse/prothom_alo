
Downloaded From BanglaFonts.com
-------------------------------

Steps for downloading and installing Bangla/Bengali Fonts:
=========================================================

Open the Windows Explorer and go to C\Windows\Fonts directory. This is your font directory. Then go to Control Panel, Click on Fonts , then Click on "Install New Fonts" and go to the directory where you downloaded/extracted the fonts/file. Select all the fonts and Click OK. This will install the required fonts. 

You should now be able to see the Bangla/Bengali Fonts from MS Word program. Please check it. 

If you can see, then restart the computer once again and start the Windows and web browser. 

You should be able to see the Bangla/bengali scripts in our Bangla/bengali website now. 



For More Fonts and Instructions visit:
--------------------------------------

http://www.BanglaFonts.com
